SKY'S FIRST BIRTHDAY INVITATION

This is a complete static website bundle.

Preview: open index.html in a browser.
To share a web link with friends, upload the entire sky-birthday-invitation folder to a static website host. Keep the folder structure intact so the photos, videos, and music load correctly.

The videos are controlled by scrolling. Music attempts autoplay; browser settings may require visitors to tap the music button.
